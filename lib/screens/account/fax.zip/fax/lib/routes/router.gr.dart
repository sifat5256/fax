// dart format width=80
// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouterGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

part of 'router.dart';

/// generated route for
/// [AccountScreen]
class AccountRoute extends PageRouteInfo<void> {
  const AccountRoute({List<PageRouteInfo>? children})
    : super(AccountRoute.name, initialChildren: children);

  static const String name = 'AccountRoute';

  static PageInfo page = PageInfo(
    name,
    builder: (data) {
      return const AccountScreen();
    },
  );
}

/// generated route for
/// [AiToolsScreen]
class AiToolsRoute extends PageRouteInfo<void> {
  const AiToolsRoute({List<PageRouteInfo>? children})
    : super(AiToolsRoute.name, initialChildren: children);

  static const String name = 'AiToolsRoute';

  static PageInfo page = PageInfo(
    name,
    builder: (data) {
      return const AiToolsScreen();
    },
  );
}

/// generated route for
/// [GenerateFaxNumberScreen]
class GenerateFaxNumberRoute extends PageRouteInfo<void> {
  const GenerateFaxNumberRoute({List<PageRouteInfo>? children})
    : super(GenerateFaxNumberRoute.name, initialChildren: children);

  static const String name = 'GenerateFaxNumberRoute';

  static PageInfo page = PageInfo(
    name,
    builder: (data) {
      return const GenerateFaxNumberScreen();
    },
  );
}

/// generated route for
/// [HomeScreen]
class HomeRoute extends PageRouteInfo<void> {
  const HomeRoute({List<PageRouteInfo>? children})
    : super(HomeRoute.name, initialChildren: children);

  static const String name = 'HomeRoute';

  static PageInfo page = PageInfo(
    name,
    builder: (data) {
      return const HomeScreen();
    },
  );
}

/// generated route for
/// [NewFaxScreen]
class NewFaxRoute extends PageRouteInfo<void> {
  const NewFaxRoute({List<PageRouteInfo>? children})
    : super(NewFaxRoute.name, initialChildren: children);

  static const String name = 'NewFaxRoute';

  static PageInfo page = PageInfo(
    name,
    builder: (data) {
      return const NewFaxScreen();
    },
  );
}

/// generated route for
/// [ProfileDetailScreen]
class ProfileDetailRoute extends PageRouteInfo<void> {
  const ProfileDetailRoute({List<PageRouteInfo>? children})
    : super(ProfileDetailRoute.name, initialChildren: children);

  static const String name = 'ProfileDetailRoute';

  static PageInfo page = PageInfo(
    name,
    builder: (data) {
      return const ProfileDetailScreen();
    },
  );
}

/// generated route for
/// [ShellScreen]
class ShellRoute extends PageRouteInfo<void> {
  const ShellRoute({List<PageRouteInfo>? children})
    : super(ShellRoute.name, initialChildren: children);

  static const String name = 'ShellRoute';

  static PageInfo page = PageInfo(
    name,
    builder: (data) {
      return const ShellScreen();
    },
  );
}

/// generated route for
/// [SubscriptionsScreen]
class SubscriptionsRoute extends PageRouteInfo<void> {
  const SubscriptionsRoute({List<PageRouteInfo>? children})
    : super(SubscriptionsRoute.name, initialChildren: children);

  static const String name = 'SubscriptionsRoute';

  static PageInfo page = PageInfo(
    name,
    builder: (data) {
      return const SubscriptionsScreen();
    },
  );
}

/// generated route for
/// [TemplateScreen]
class TemplateRoute extends PageRouteInfo<void> {
  const TemplateRoute({List<PageRouteInfo>? children})
    : super(TemplateRoute.name, initialChildren: children);

  static const String name = 'TemplateRoute';

  static PageInfo page = PageInfo(
    name,
    builder: (data) {
      return const TemplateScreen();
    },
  );
}
