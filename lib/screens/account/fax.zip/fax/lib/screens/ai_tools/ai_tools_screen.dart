import 'package:auto_route/annotations.dart';
import 'package:fax/components/utilities.dart';
import 'package:flutter/material.dart';

import '../../theme.dart';

@RoutePage()
class AiToolsScreen extends StatelessWidget {
  const AiToolsScreen({super.key});

  final List<AiToolsItemModel> items = const [
    AiToolsItemModel(
      icon: "assets/icons/mountain.svg",
      title: "OCR Scanner",
      description: "Extract text from documents",
    ),
    AiToolsItemModel(
      icon: "assets/icons/mountain.svg",
      title: "Image Enhancement",
      description: "Improve document clarity",
    ),
    AiToolsItemModel(
      icon: "assets/icons/mountain.svg",
      title: "Translation",
      description: "Translate to any language",
    ),
    AiToolsItemModel(
      icon: "assets/icons/mountain.svg",
      title: "Summary Generator",
      description: "Auto-generate summaries",
    ),
    AiToolsItemModel(
      icon: "assets/icons/mountain.svg",
      title: "Redaction Tool",
      description: "Hide sensitive information",
    ),
    AiToolsItemModel(
      icon: "assets/icons/mountain.svg",
      title: "Form Filler",
      description: "Auto-fill forms with AI",
    ),
    AiToolsItemModel(
      icon: "assets/icons/mountain.svg",
      title: "E-Sign",
      description: "Digitally sign documents",
    ),
    AiToolsItemModel(
      icon: "assets/icons/mountain.svg",
      title: "Edit Docs",
      description: "Edit and annotate documents",
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surfaceColor,
      appBar: _appBar(),
      body: SingleChildScrollView(
        padding: defaultPaddingHorizontal(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(height: 10),
            _recentFiles(),
            SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  EdgeInsets defaultPaddingHorizontal() {
    return const EdgeInsets.symmetric(horizontal: 16);
  }

  PreferredSizeWidget _appBar() {
    return AppBar(
      automaticallyImplyLeading: false,
      surfaceTintColor: AppColors.cardColor,
      backgroundColor: AppColors.cardColor,
      title: Text(
        "Ai",
        style: TextStyle(fontWeight: FontWeight.w600),
      ),
      actions: [
        Container(
          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
          decoration: BoxDecoration(
            color: Color(0xFFFF7428),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Text(
            "Premium",
            style: TextStyle(color: AppColors.onPrimary),
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );
  }

  Widget _recentFiles() {
    return AiToolsAutoGridItems(items: items);
  }
}
