package com.example.fax

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
